Scoped existing-site update, 2026-11-21
Target directory: /SHANLE_LAB_Retail_Cases/
Upload only files in SHANLE_LAB_Retail_Cases; preserve all existing unrelated files.
Existing niko case URL retained. Previous case kept at places/place-99946a12e1-before-christmas.html.
Do not delete existing assets, archive, style.css or site.js.
This package does not claim publication. Verify live case title, 19-photo report link, 35/36 positions and new hero after upload.
